module.exports = {
  extends: 'algolia',
};
